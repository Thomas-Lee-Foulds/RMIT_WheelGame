package client;

import javax.swing.SwingUtilities;

import model.GameEngineImpl;
import model.interfaces.GameEngine;
import view.GameEngineCallBackGUI;
import view.GameEngineCallbackImpl;
import view.MainFrame;
import view.interfaces.GameEngineCallback;

public class MainClient {

	public static void main(String[] args) {
		GameEngine gmEngine = new GameEngineImpl();
		GameEngineCallback callback = new GameEngineCallbackImpl();
		gmEngine.addGameEngineCallback(callback);
		 SwingUtilities.invokeLater(new Runnable()
		 {
			 @Override
			 public void run()
			 {
			   MainFrame frame = new MainFrame(gmEngine);
			   GameEngineCallBackGUI callbackGUI = new GameEngineCallBackGUI(frame);
			   gmEngine.addGameEngineCallback(callbackGUI);
			 }
		 });

		
	}

}
