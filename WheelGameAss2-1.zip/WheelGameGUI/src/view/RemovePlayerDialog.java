package view;

import java.awt.BorderLayout;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import controller.PlayerRemoveListener;
import model.interfaces.GameEngine;
import model.interfaces.Player;

@SuppressWarnings("serial")
public class RemovePlayerDialog extends JDialog {
	private JPanel panel;
	private Collection<Player> players;
	private JComboBox<Player> combo;
	private JLabel title;
	private JButton submit;
	public RemovePlayerDialog(GameEngine engine, MainFrame mainFrame) {
		this.setTitle("Remove Player");
		panel = new JPanel();
		players = engine.getAllPlayers();
		combo = new JComboBox(players.toArray());
		title = new JLabel("Select Player To Delete", SwingConstants.CENTER);
		submit = new JButton("Submit");
		submit.addActionListener(new PlayerRemoveListener(engine,this, mainFrame));
		panel.add(title, BorderLayout.NORTH);
		panel.add(combo, BorderLayout.CENTER);
		panel.add(submit, BorderLayout.SOUTH);
		add(panel);
		setSize(500,150);
		setVisible(true);
	}
	
	public Player getSelected() {
		return (Player)combo.getSelectedItem();
	}
}
