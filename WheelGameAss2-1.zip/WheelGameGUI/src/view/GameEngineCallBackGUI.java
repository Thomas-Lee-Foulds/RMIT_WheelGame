package view;

import javax.swing.SwingUtilities;

import model.interfaces.GameEngine;
import model.interfaces.Slot;
import view.interfaces.GameEngineCallback;

public class GameEngineCallBackGUI implements GameEngineCallback {

	private MainFrame frame;
	public GameEngineCallBackGUI(MainFrame frame) {
		this.frame = frame;
	}

	@Override
	public void nextSlot(Slot slot, GameEngine engine) {
		SwingUtilities.invokeLater(new Runnable()
		 {
			 @Override
			 public void run()
			 {
			   frame.getStatusBar().setSlotInfo(slot.toString());
			   frame.getWheelPanel().setVariables(slot.getPosition());
			   frame.getWheelPanel().repaint();
			 }
		 });
		
	}

	@Override
	public void result(Slot winningSlot, GameEngine engine) {
		SwingUtilities.invokeLater(new Runnable()
		 {
			 @Override
			 public void run()
			 {
				 frame.getWheelPanel().setVariables(winningSlot.getPosition());
				 frame.getWheelPanel().repaint();
				 frame.getStatusBar().setSlotInfo(winningSlot.toString());
				 frame.getStatusBar().setResultInfo("Result: " + winningSlot.getColor());
				 frame.getSummaryPanel().tableChanged();
				 frame.getSummaryPanel().updatePointsArray();
			 }
		 });
	}

}
