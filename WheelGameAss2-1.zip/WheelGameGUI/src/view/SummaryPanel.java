package view;

import java.awt.Dimension;
import java.util.Collection;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import model.interfaces.GameEngine;
import model.interfaces.Player;

@SuppressWarnings("serial")
public class SummaryPanel extends JPanel {
	private Border raisedBevel;
	private Collection<Player> players;
	private JTable table;
	private JScrollPane pane;
	private Vector<Vector<String>> data;
	private Vector<String> header;
	private DefaultTableModel model; 
	private GameEngine engine;
	private int[] points;
	private int PANE_WIDTH = 225, PANE_HEIGHT = 200;

	public SummaryPanel(GameEngine engine){
		this.engine = engine;
		raisedBevel = BorderFactory.createRaisedBevelBorder();
		header = new Vector<String>();
		data = new Vector<Vector<String>>();
		header.add("Name");
		header.add("Points");
		header.add("Bet");
		header.add("BetType");
		header.add("Latest");
		model = new DefaultTableModel(data,header);
		table = new JTable(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		pane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		pane.setPreferredSize(new Dimension(PANE_WIDTH,PANE_HEIGHT));
		add(pane);
		setVisible(true);
		setBorder(raisedBevel);
	}
	
	public void tableChanged(){
		players = engine.getAllPlayers();
		model.setRowCount(0);
		int i = 0;
		for(Player player : players){
			Vector<String> playerVector = new Vector<String>();
			playerVector.add(player.getPlayerName());
			playerVector.add(String.valueOf(player.getPoints()));
			playerVector.add(String.valueOf(player.getBet()));
			if(player.getBetType() == null){
				playerVector.add("Null");
			}else{
				playerVector.add(String.valueOf(player.getBetType()));
			}
			playerVector.add(String.valueOf(player.getPoints()-points[i]));
			data.add(playerVector);
			i++;
		}
		model.fireTableDataChanged();
	}
	public void updatePointsArray(){
		
		int i = 0;
		players = engine.getAllPlayers();
		points = new int[players.size()];
		for(Player player : players){
			points[i] = player.getPoints();
			i++;
		}
	}
}
