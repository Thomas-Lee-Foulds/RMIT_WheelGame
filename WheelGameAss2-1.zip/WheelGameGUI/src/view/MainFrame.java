package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import model.interfaces.GameEngine;

@SuppressWarnings("serial")
public class MainFrame extends JFrame {
	private Toolbar toolbar;
	private StatusBar status;
	private GUIMenuBar bar;
	private WheelPanel wheelpanel;
	private SummaryPanel summarypanel;
	public MainFrame(GameEngine gmEngine){
		super("Wheel Game Assignment 2");
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		screenSize.setSize(screenSize.getWidth()/2,screenSize.getHeight()/2);
		setSize(screenSize);
		this.setMinimumSize(screenSize);
		this.setIconImage(new ImageIcon("image/Roulette_Wheel.png").getImage());
		status = new StatusBar();
		toolbar = new Toolbar(gmEngine, this);
		bar = new GUIMenuBar(gmEngine, this);
		wheelpanel = new WheelPanel();
		summarypanel = new SummaryPanel(gmEngine);
		this.setJMenuBar(bar);
		add(toolbar, BorderLayout.NORTH);
		add(wheelpanel, BorderLayout.CENTER);
		add(status, BorderLayout.SOUTH);
		add(summarypanel,BorderLayout.EAST);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}
	public StatusBar getStatusBar(){
		return status;
	}
	
	public SummaryPanel getSummaryPanel(){
		return summarypanel;
	}
	
	public WheelPanel getWheelPanel(){
		return wheelpanel;
	}
	
	public Toolbar getToolBar(){
		return toolbar;
	}
	
	public GUIMenuBar getGUIMenuBar(){
		return bar;
	}
}
