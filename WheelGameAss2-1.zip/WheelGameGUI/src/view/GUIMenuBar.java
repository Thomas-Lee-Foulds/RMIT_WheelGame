package view;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import controller.RemovePlayerDialogListener;
import controller.SetBetDialogListener;
import controller.CreatePlayerDialogListener;
import model.interfaces.GameEngine;

@SuppressWarnings("serial")
public class GUIMenuBar extends JMenuBar {
	private JMenuBar menuBar;
	private JMenuItem addPlayer,removePlayer, setBets;
	private JMenu playerMenu, betMenu;

	public GUIMenuBar(GameEngine gmEngine, MainFrame mainFrame){
		//Create two JMenu with player and bet player(add, remove) bet(set,reset) 
		menuBar = new JMenuBar();
		playerMenu = new JMenu("Player");
		betMenu = new JMenu("Bet");

		//create dialog for player creation 
		addPlayer = new JMenuItem("Add Player");
		addPlayer.addActionListener(new CreatePlayerDialogListener(gmEngine, mainFrame));
		
		//create dialog for player deletion(referring to id or name(TBD) to find)
		removePlayer = new JMenuItem("RemovePlayer");
		removePlayer.addActionListener(new RemovePlayerDialogListener(gmEngine, mainFrame));
		
		//create dialog that either has each player or one for each player to set bet
		setBets = new JMenuItem("Set Player Bets");
		setBets.addActionListener(new SetBetDialogListener(gmEngine, mainFrame));
		
		playerMenu.add(addPlayer);
		playerMenu.add(removePlayer);
		betMenu.add(setBets);
		
		menuBar.add(playerMenu);
		menuBar.add(betMenu);
		add(menuBar);
	}
	
	public void disableItems(){
		addPlayer.setEnabled(false);
		removePlayer.setEnabled(false);
		setBets.setEnabled(false);
	}
	
	public void activateItems(){
		addPlayer.setEnabled(true);
		removePlayer.setEnabled(true);
		setBets.setEnabled(true);
	}
}
