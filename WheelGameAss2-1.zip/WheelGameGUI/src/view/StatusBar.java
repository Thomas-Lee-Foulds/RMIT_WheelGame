package view;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

@SuppressWarnings("serial")
public class StatusBar extends JPanel{
	private static JLabel status, slot, result;
	private Border raisedBevel;
	public StatusBar(){
		raisedBevel = BorderFactory.createRaisedBevelBorder();

		slot = new JLabel("Slot Not Available", SwingConstants.CENTER);
		status = new JLabel("Current Slot: ", SwingConstants.RIGHT);
		result = new JLabel("Result Not Available", SwingConstants.RIGHT);
		setLayout(new GridLayout(1,3));
		add(status);
		add(slot);
		add(result);

		setBorder(raisedBevel);
	}
	
	public void setSlotInfo(String slotInfo){
		slot.setText(slotInfo);
	}

	public void setResultInfo(String resultInfo){
		result.setText(resultInfo);
	}
	
}
