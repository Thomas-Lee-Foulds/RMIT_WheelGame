package view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.PlayerAdditionListener;
import model.interfaces.GameEngine;

@SuppressWarnings("serial")
public class PlayerCreateDialog extends JDialog {
	private JPanel panel;
	private JButton submit;
	private JLabel idLabel, nameLabel, pointsLabel;
	private JTextField idField, nameField,pointsField;
	public PlayerCreateDialog(GameEngine gmEngine, MainFrame mainFrame){
		
		panel = new JPanel();
		this.setTitle("Create Player");
		panel.setLayout(new GridLayout(0,2));
		
		idLabel = new JLabel("Enter Id: ");
		panel.add(idLabel);
		idField = new JTextField();
		idLabel.setLabelFor(idField);
		panel.add(idField);
		
		nameLabel = new JLabel("Enter Name: ");
		panel.add(nameLabel);
		nameField = new JTextField();
		nameLabel.setLabelFor(nameField);
		panel.add(nameField);
		
		pointsLabel = new JLabel("Enter Points: ");
		panel.add(pointsLabel);
		pointsField = new JTextField();
		pointsLabel.setLabelFor(pointsField);
		panel.add(pointsField);
		
		submit = new JButton("Submit");
		//put this in a controller with get methods
		submit.addActionListener(new PlayerAdditionListener(gmEngine,this, mainFrame));
		panel.add(submit);
		
		add(panel);
		setSize(200,200);
		setVisible(true);
	}
	
	public String getPlayerID(){
		return idField.getText();
	}
	public String getPlayerName(){
		return nameField.getText();
	}
	public String getPlayerPoints(){
		return pointsField.getText();
	}
}
