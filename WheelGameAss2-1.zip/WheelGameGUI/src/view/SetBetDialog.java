package view;

import java.awt.GridLayout;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.SetPlayerBetListener;
import model.enumeration.BetType;
import model.interfaces.GameEngine;
import model.interfaces.Player;

@SuppressWarnings("serial")
public class SetBetDialog extends JDialog {
	private Collection<Player> players;
	private JComboBox<Player> combo;
	private JComboBox<BetType> betCombo;
	private JButton submit;
	private JLabel title, pointsLabel, betlabel;
	private JPanel panel;
	private JTextField points;
	private MainFrame frame;
	private GameEngine engine;
	public SetBetDialog(GameEngine engine, MainFrame frame) {
		this.setTitle("Set Player Bet");
		this.frame = frame;
		this.engine = engine;
		panel = new JPanel();
		panel.setLayout(new GridLayout(0,2));
		players = engine.getAllPlayers();
		title = new JLabel("Select Player to set bet:");
		title.setLabelFor(combo);
		panel.add(title);
		combo = new JComboBox(players.toArray());
		panel.add(combo);
		betlabel = new JLabel("Pick Bet Type");
		betCombo = new JComboBox<BetType>(BetType.values());
		betlabel.setLabelFor(betCombo);
		panel.add(betlabel);
		panel.add(betCombo);
		
		points = new JTextField();
		pointsLabel = new JLabel("Enter Amount of Points: ");
		pointsLabel.setLabelFor(points);
		panel.add(pointsLabel);
		panel.add(points);
		
		submit = new JButton("Submit");
		submit.addActionListener(new SetPlayerBetListener(engine, this, frame));
		
		panel.add(submit);
		add(panel);
		setSize(900,120);
		setVisible(true);
	}
	public String getPointsValue(){
		return points.getText();
	}
	public Player getPlayerValue(){
		return (Player)combo.getSelectedItem();
	}
	
	public BetType getBetValue(){
		return (BetType)betCombo.getSelectedItem();
	}
	
	public void checkBetsforSpin(){
		int check = 0;
		for(Player player : engine.getAllPlayers()){
			if(player.getBetType() == null){
				check = 1;
				break;
			}
		}
		if(check == 0 && engine.getAllPlayers().size() != 0){
			new Thread()
			{
				@Override
				 public void run()
				 {
					frame.getToolBar().disableButtons();
					frame.getGUIMenuBar().disableItems();
					engine.spin(1,200,4);
					frame.getToolBar().activateButtons();
					frame.getGUIMenuBar().activateItems();
				 }
			}.start();
		}
	}
}
