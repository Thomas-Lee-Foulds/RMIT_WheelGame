package view;



import javax.swing.JButton;
import javax.swing.JToolBar;

import controller.RemovePlayerDialogListener;
import controller.SetBetDialogListener;
import controller.SpinListener;
import controller.CreatePlayerDialogListener;
import model.interfaces.GameEngine;
	
@SuppressWarnings("serial")
public class Toolbar extends JToolBar {
	private JButton addPlayer, removePlayer, setBets, spin;

	public Toolbar(GameEngine gmEngine, MainFrame mainFrame){
		//change these to buttons
		addPlayer = new JButton("Add Player");
		addPlayer.addActionListener(new CreatePlayerDialogListener(gmEngine, mainFrame));
		removePlayer = new JButton("Remove Player");
		removePlayer.addActionListener(new RemovePlayerDialogListener(gmEngine, mainFrame));
		setBets = new JButton("Set Bets");
		setBets.addActionListener(new SetBetDialogListener(gmEngine, mainFrame));
		spin = new JButton("Spin");
		spin.addActionListener(new SpinListener(gmEngine, mainFrame));
		add(addPlayer);
		add(removePlayer);
		add(setBets);
		add(spin);
		//create a combobox of players that can be selected for certain commands
	}
	
	public void disableButtons(){
		addPlayer.setEnabled(false);
		removePlayer.setEnabled(false);
		spin.setEnabled(false);
		setBets.setEnabled(false);
	}
	
	public void activateButtons(){
		addPlayer.setEnabled(true);
		removePlayer.setEnabled(true);
		spin.setEnabled(true);
		setBets.setEnabled(true);
	}
	
}
