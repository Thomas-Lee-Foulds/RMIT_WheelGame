package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class WheelPanel extends JPanel {
	private Image wheel = new ImageIcon("image/Roulette_Wheel.png").getImage();
	private Image background = new ImageIcon("image/background.jpg").getImage();
	private int size, x, y;
	private double radians = 0, angle, position;
	private int BALL_SIZE, FULL_CIRCLE = 360, QUARTER_CIRCLE = 90, BALL_MULT = 25;
	private double SLOT_SIZE = 0.925, RADIAN_CALC = 0.0174533;

	public WheelPanel(){
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//This is the estimate size of the slots being taken away from the wheel images size which will then be
		//halved in order to find the center of the circle and center of the slot.
		x = (int) (((size  * SLOT_SIZE)/2) * Math.cos(radians)); 
		y = (int) (((size * SLOT_SIZE)/2) * Math.sin(radians));
        if(wheel != null){
        	//this dynamically sets the wheels size based on with part of the frame is larger
        	if(getHeight() < getWidth()){
        		size = getHeight();
        		BALL_SIZE = size/BALL_MULT;
        	}
        	else{
        		size = getWidth();
        		BALL_SIZE = size/BALL_MULT;
        	}
        	//to make the background look nice i added a dynamic background to it underneath the wheel
        	g.drawImage(background, 0, 0,getWidth(),getHeight(), this);
        	g.drawImage(wheel, (getWidth()-size)/2, (getHeight()-size)/2,size,size, this);	
        }
        g.setColor(Color.GREEN);
        g.fillOval((((getWidth()-BALL_SIZE)/2)+ x), (((getHeight()-BALL_SIZE)/2)+ y), BALL_SIZE, BALL_SIZE);
	  }
	
	public void setVariables(int position){
		//this takes the current position gets a percentage representation of it which is then used to get an angle and radian 
		this.position = ((double)position/38);
		angle = (FULL_CIRCLE * this.position) - QUARTER_CIRCLE;
		radians = angle * RADIAN_CALC;
	}
}
