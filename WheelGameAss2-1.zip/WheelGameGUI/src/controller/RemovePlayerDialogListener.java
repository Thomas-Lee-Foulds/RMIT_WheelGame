package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.interfaces.GameEngine;
import view.MainFrame;
import view.RemovePlayerDialog;

public class RemovePlayerDialogListener implements ActionListener {
	private GameEngine engine;
	private MainFrame mainFrame;
	public RemovePlayerDialogListener(GameEngine gmEngine, MainFrame mainFrame) {
		engine = gmEngine;
		this.mainFrame = mainFrame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		new RemovePlayerDialog(engine, mainFrame);

	}

}
