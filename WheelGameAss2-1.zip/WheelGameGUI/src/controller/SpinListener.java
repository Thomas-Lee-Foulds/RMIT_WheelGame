package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.interfaces.GameEngine;
import view.MainFrame;

public class SpinListener implements ActionListener {
	private GameEngine engine;
	private MainFrame frame;
	public SpinListener(GameEngine gmEngine, MainFrame mainFrame) {
		engine = gmEngine;
		this.frame = mainFrame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		new Thread()
		{
			@Override
			 public void run()
			 {
				frame.getToolBar().disableButtons();
				frame.getGUIMenuBar().disableItems();
				engine.spin(1,200,4);
				frame.getToolBar().activateButtons();
				frame.getGUIMenuBar().activateItems();
			 }
		}.start();
	}

}
