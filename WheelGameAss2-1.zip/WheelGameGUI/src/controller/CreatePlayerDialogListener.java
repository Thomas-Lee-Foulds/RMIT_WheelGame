package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.interfaces.GameEngine;
import view.MainFrame;
import view.PlayerCreateDialog;

public class CreatePlayerDialogListener implements ActionListener {
	private GameEngine gmEngine;
	private MainFrame mainFrame;
	public CreatePlayerDialogListener(GameEngine gmEngine, MainFrame mainFrame){
		this.mainFrame = mainFrame;
		this.gmEngine = gmEngine;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		new PlayerCreateDialog(gmEngine, mainFrame);
	}

}
