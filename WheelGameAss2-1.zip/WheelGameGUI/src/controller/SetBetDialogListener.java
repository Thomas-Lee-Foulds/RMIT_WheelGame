package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.interfaces.GameEngine;
import view.MainFrame;
import view.SetBetDialog;

public class SetBetDialogListener implements ActionListener {
	private GameEngine engine;
	private MainFrame frame;
	public SetBetDialogListener(GameEngine gmEngine, MainFrame mainFrame) {
		this.engine = gmEngine;
		this.frame = mainFrame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		new SetBetDialog(engine, frame);
	}

}
