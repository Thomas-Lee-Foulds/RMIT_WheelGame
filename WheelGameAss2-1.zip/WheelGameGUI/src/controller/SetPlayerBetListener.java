package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.enumeration.BetType;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;
import view.SetBetDialog;

public class SetPlayerBetListener implements ActionListener {
	private GameEngine engine;
	private SetBetDialog dialog;
	private MainFrame frame;
	private Player player;
	private int bet, check;
	private BetType betType;
	
	public SetPlayerBetListener(GameEngine engine, SetBetDialog setBetDialog, MainFrame frame) {
		this.engine = engine;
		this.dialog = setBetDialog;
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		check = 0;
		player = dialog.getPlayerValue();
		betType = dialog.getBetValue();
		try
	    {
	    	bet = Integer.parseInt(dialog.getPointsValue());
	    }
	    catch (NumberFormatException nfe)
	    {
	      System.out.println("NumberFormatException: " + nfe.getMessage() + " in bet points");
	      check = 1;
	    }
		if(player != null && betType != null && check == 0 && player.getPoints() >= bet && bet != 0){
			engine.placeBet(player, bet, betType);
			frame.getSummaryPanel().tableChanged();
			dialog.dispose();
		}else{
			JOptionPane.showMessageDialog(dialog ,"Incorrect: Invalid input Scanned","Alert",JOptionPane.WARNING_MESSAGE);
		}
		dialog.checkBetsforSpin();
	}
}
