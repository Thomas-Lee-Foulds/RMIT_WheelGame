package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.SimplePlayer;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import view.MainFrame;
import view.PlayerCreateDialog;

public class PlayerAdditionListener implements ActionListener {
	private GameEngine engine;
	private PlayerCreateDialog dialog;
	private MainFrame mainFrame;
	private String id,name;
	private int points, check;
	private Player player;
	public PlayerAdditionListener(GameEngine gmEngine, PlayerCreateDialog dialog, MainFrame mainFrame) {
		this.engine = gmEngine;
		this.dialog = dialog;
		this.mainFrame = mainFrame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		check = 0;
		id = dialog.getPlayerID();
		name = dialog.getPlayerName();
		points = 0;
		try
	    {
	    	points = Integer.parseInt(dialog.getPlayerPoints());
	    }
	    catch (NumberFormatException nfe)
	    {
	      System.out.println("NumberFormatException: " + nfe.getMessage() + " in points");
	      check = 1;
	    }
		if(check == 0 && id != null && name != null && points > 0 && !id.equals("") && !name.equals("")){
			new Thread()
			{
				@Override
				 public void run()
				 {
					player = new SimplePlayer(id,name,points);
					engine.addPlayer(player);
					mainFrame.getSummaryPanel().updatePointsArray();
					mainFrame.getSummaryPanel().tableChanged();
					dialog.dispose();
				 }
			}.start();
		}
		else{
			JOptionPane.showMessageDialog(dialog ,"Incorrect input: Make Sure Input is valid.","Invalid Input",JOptionPane.ERROR_MESSAGE);
		}
	}
}
