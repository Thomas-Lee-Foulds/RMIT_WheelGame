package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;

import javax.swing.JOptionPane;

import model.interfaces.GameEngine;
import view.MainFrame;
import view.RemovePlayerDialog;

public class PlayerRemoveListener extends Observable implements ActionListener {
	private GameEngine engine;
	private RemovePlayerDialog dialog;
	private MainFrame frame;
	public PlayerRemoveListener(GameEngine engine, RemovePlayerDialog dialog, MainFrame mainFrame) {
		this.engine = engine;
		this.dialog = dialog;
		this.frame = mainFrame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(dialog.getSelected() != null){
			new Thread()
			{
				@Override
				 public void run()
				 {
					engine.removePlayer(dialog.getSelected());
					frame.getSummaryPanel().updatePointsArray();
					frame.getSummaryPanel().tableChanged();
					dialog.dispose();
				 }
			}.start();
			engine.removePlayer(dialog.getSelected());
		}else{
			JOptionPane.showMessageDialog(dialog ,"Error: No Player Is Selected","Alert",JOptionPane.WARNING_MESSAGE);
		}
	}

}
