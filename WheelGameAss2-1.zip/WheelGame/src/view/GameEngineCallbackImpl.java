package view;

import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.Slot;
import view.interfaces.GameEngineCallback;

/**
 * 
 * Skeleton/Partial example implementation of GameEngineCallback showing Java logging behaviour
 * 
 * @author Caspar Ryan
 * @see view.interfaces.GameEngineCallback
 * 
 */
public class GameEngineCallbackImpl implements GameEngineCallback
{
   private static final Logger logger = Logger.getLogger(GameEngineCallback.class.getName());

   public GameEngineCallbackImpl()
   {
      // FINE shows wheel spinning output, INFO only shows result
      logger.setLevel(Level.FINE);
   }

   @Override
   public void nextSlot(Slot slot, GameEngine engine)
   {
      logger.log(Level.INFO, "Next Slot:" + slot.toString());
   }

   @Override
   public void result(Slot result, GameEngine engine)
   {
	  StringBuilder sb = new StringBuilder();
	  Collection<Player> players = engine.getAllPlayers();
      logger.log(Level.INFO, "Result=" + result.toString() + "\n");
      logger.log(Level.INFO, "FINAL PLAYER POINT BALANCES");
      engine.calculateResult(result);
      for(Player playerPrint: players){
    	 sb.append(playerPrint.toString());
      }
      logger.log(Level.INFO, sb.toString());
      for(Player player: players){
    	  player.resetBet();
      }
   }
}
