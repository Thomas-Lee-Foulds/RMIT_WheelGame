package model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import model.enumeration.BetType;
import model.enumeration.Color;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.Slot;
import view.interfaces.GameEngineCallback;

public class GameEngineImpl implements GameEngine {
	private int ZERO = 0;
	private Map<String,Player> players = new HashMap<String,Player>();
	private Collection<Slot> slotWheel = new ArrayList<Slot>();
	private ArrayList<GameEngineCallback> gameEngineCallbacks = new ArrayList<GameEngineCallback>();
	
	public GameEngineImpl(){
		slotWheel = getWheelSlots();
	}
	public void spin(int initialDelay, int finalDelay, int delayIncrement) {
		//selects random num using random import, it then goes through the arraylist with to array 
		//starting at the random index num
		int delay = initialDelay;
		Slot startSlot;
		Random rand = new Random();
		int randSlot = rand.nextInt(Slot.WHEEL_SIZE);
		startSlot = (Slot) slotWheel.toArray()[randSlot];
		int slotNum = startSlot.getPosition();
		while(delay <= finalDelay){
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			slotNum++;
			if(slotNum == Slot.WHEEL_SIZE){
				slotNum = ZERO;
			}
			startSlot = (Slot) slotWheel.toArray()[slotNum];
			if((delay + delayIncrement) > finalDelay)
				break;
			for(GameEngineCallback gameEngineCallback: gameEngineCallbacks){
				gameEngineCallback.nextSlot(startSlot, this);
			}
			
			delay += delayIncrement;
		}
		for(GameEngineCallback gameEngineCallback: gameEngineCallbacks){
			gameEngineCallback.result(startSlot, this);
		}
		
	}

	public void calculateResult(Slot winningSlot) {
		for(Player player: players.values()){
			if(player.getBetType() != null)
				player.getBetType().applyWinLoss(player, winningSlot);
		}
	}

	public void addPlayer(Player player) {
		//checks players for same id then makes decision of either replacing or adding depending
		//from this if statement
		
		players.put(player.getPlayerId(),player);
	}

	public Player getPlayer(String id) {
		return players.get(id);
	}

	public boolean removePlayer(Player player) {
		return players.remove(player.getPlayerId(),player);
	}

	public void addGameEngineCallback(GameEngineCallback gameEngineCallback) {
		gameEngineCallbacks.add(gameEngineCallback);
	}

	public boolean removeGameEngineCallback(GameEngineCallback gameEngineCallback) {
		for(GameEngineCallback gameEngineCallbackIt: gameEngineCallbacks){
			if(gameEngineCallback.equals(gameEngineCallbackIt))
				gameEngineCallbacks.remove(gameEngineCallbackIt);
		}
		
		return false;
	}

	public Collection<Player> getAllPlayers() {
		List<Player> list = new ArrayList<Player>(players.values());
		List<Player> unmodifiable = Collections.unmodifiableList(list);
		return unmodifiable;
	}

	public boolean placeBet(Player player, int bet, BetType betType) {
		//checking if bet is higher then 0, and higher then points, if so true, else false
		if(player.setBet(bet)){
			player.setBetType(betType);
			return true;
		}
		return false;
	}

	public Collection<Slot> getWheelSlots() {
		//hard codes a wheel and returns it.
		slotWheel.add(new SlotImpl(0,Color.GREEN00,0));
		slotWheel.add(new SlotImpl(1,Color.RED,27));
		slotWheel.add(new SlotImpl(2,Color.BLACK,10));
		slotWheel.add(new SlotImpl(3,Color.RED,25));
		slotWheel.add(new SlotImpl(4,Color.BLACK,29));
		slotWheel.add(new SlotImpl(5,Color.RED,12));
		slotWheel.add(new SlotImpl(6,Color.BLACK,8));
		slotWheel.add(new SlotImpl(7,Color.RED,19));
		slotWheel.add(new SlotImpl(8,Color.BLACK,31));
		slotWheel.add(new SlotImpl(9,Color.RED,18));
		slotWheel.add(new SlotImpl(10,Color.BLACK,6));
		slotWheel.add(new SlotImpl(11,Color.RED,21));
		slotWheel.add(new SlotImpl(12,Color.BLACK,33));
		slotWheel.add(new SlotImpl(13,Color.RED,16));
		slotWheel.add(new SlotImpl(14,Color.BLACK,4));
		slotWheel.add(new SlotImpl(15,Color.RED,23));
		slotWheel.add(new SlotImpl(16,Color.BLACK,35));
		slotWheel.add(new SlotImpl(17,Color.RED,14));
		slotWheel.add(new SlotImpl(18,Color.BLACK,2));
		slotWheel.add(new SlotImpl(19,Color.GREEN0,0));
		slotWheel.add(new SlotImpl(20,Color.BLACK,28));
		slotWheel.add(new SlotImpl(21,Color.RED,9));
		slotWheel.add(new SlotImpl(22,Color.BLACK,26));
		slotWheel.add(new SlotImpl(23,Color.RED,30));
		slotWheel.add(new SlotImpl(24,Color.BLACK,11));
		slotWheel.add(new SlotImpl(25,Color.RED,7));
		slotWheel.add(new SlotImpl(26,Color.BLACK,20));
		slotWheel.add(new SlotImpl(27,Color.RED,32));
		slotWheel.add(new SlotImpl(28,Color.BLACK,17));
		slotWheel.add(new SlotImpl(29,Color.RED,5));
		slotWheel.add(new SlotImpl(30,Color.BLACK,22));
		slotWheel.add(new SlotImpl(31,Color.RED,34));
		slotWheel.add(new SlotImpl(32,Color.BLACK,15));
		slotWheel.add(new SlotImpl(33,Color.RED,3));
		slotWheel.add(new SlotImpl(34,Color.BLACK,24));
		slotWheel.add(new SlotImpl(35,Color.RED,36));
		slotWheel.add(new SlotImpl(36,Color.BLACK,13));
		slotWheel.add(new SlotImpl(37,Color.RED,1));
		return slotWheel;
	}

}
