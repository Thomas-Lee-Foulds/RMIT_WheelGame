package model;

import model.enumeration.Color;
import model.interfaces.Slot;

public class SlotImpl implements Slot{
	private int position;
	private Color color;
	private int number;
	
	public SlotImpl(int position, Color color, int number){
		this.position = position;
		this.color = color;
		this.number = number;
	}
	
	public int getPosition() {
		return this.position;
	}

	public int getNumber() {
		return this.number;
	}

	public Color getColor() {
		return this.color;
	}

	public boolean equals(Slot slot) {
		if(this.getColor().equals(slot.getColor())){
			if(this.getNumber() == slot.getNumber()){
				return true;
			}
		}
		return false;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Slot){
			return this.equals((Slot)obj);
		}
		return false;
	}
	
	@Override
	public String toString(){
		//string.format same with player impl
		return "Position: " + this.position + ", Color: " + this.color + ", Number:" + this.number;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
	 
	

}
