package model;

import model.enumeration.BetType;
import model.interfaces.Player;

public class SimplePlayer implements Player {
	
	private String playerId;
	private String playerName;
	private int points;
	private int bet;
	private BetType betType;
	public SimplePlayer(String playerId, String playerName, int initialPoints){
		this.playerId = playerId;
		this.playerName = playerName;
		this.points = initialPoints;
		this.bet = 0;
		this.betType = null;
	}

	
	public String getPlayerName() {
		return this.playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getPoints() {
		return this.points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public String getPlayerId() {
		return this.playerId;
	}

	public boolean setBet(int bet) {
		if(bet > 0 && bet <= this.points){
			this.bet = bet;
			return true;
		}
		return false;
	}

	public int getBet() {
		return this.bet;
	}

	public void setBetType(BetType betType) {
		this.betType = betType;
	}

	public BetType getBetType() {
		return this.betType;
	}

	public void resetBet() {
		this.bet = 0;
		this.betType = null;
	}
	
	@Override
	public String toString(){
		return String.format("\nPlayer: id= " + this.playerId + ", Name=" + this.playerName + ", Bet=" + this.bet + 
				", BetType=" + this.betType + ", Points=" + this.points);
	}
}
